import { Box, Typography } from "@mui/material";

export default function Footer() {
  return (
    <Box sx={{ p: 2, textAlign: "center" }}>
      <Typography variant="body2" sx={{color: "secondary.main"}}>
        @ {new Date().getFullYear()} Pet
      </Typography>
    </Box>
  );
}
