INSERT INTO tb_pet(nome,tipo, cor) VALUES('Caramelo', 'Cachorro', 'Marrom e Branco');
INSERT INTO tb_pet(nome,tipo, cor) VALUES('Luna', 'Gato', 'Peto');
INSERT INTO tb_pet(nome,tipo, cor) VALUES('Piu-piu', 'Canário', 'Amarelo e Verde');
INSERT INTO tb_pet(nome,tipo, cor) VALUES('Frajola', 'Gato', 'Preto e Branco');
INSERT INTO tb_pet(nome,tipo, cor) VALUES('Sansão', 'Rottweiler', 'Preto e Marrom');