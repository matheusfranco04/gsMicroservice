package br.com.fiap.pets.service;

import br.com.fiap.pets.dto.PetDTO;
import br.com.fiap.pets.entity.Pet;
import br.com.fiap.pets.repository.IPetRepository;
import br.com.fiap.pets.service.exceptions.ResourceNotFoundException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PetService {

    @Autowired
    private IPetRepository repository;

    @Transactional(readOnly = true)
    public List<PetDTO> findAll() {
        return repository.findAll()
                .stream().map(PetDTO::new).toList();
    }

    @Transactional
    public PetDTO insert(PetDTO dto) {
        Pet entity = new Pet();
        copyDtoToEntity(dto, entity);
        entity = repository.save(entity);
        return new PetDTO(entity);
    }

    private void copyDtoToEntity(PetDTO dto, Pet entity) {
        entity.setId(dto.getId());
        entity.setNome(dto.getNome());
        entity.setTipo(dto.getTipo());
        entity.setCor(dto.getCor());
    }


}
